import { z } from "zod";

export const loginSchema = z.object({
  email: z
    .string()
    .trim()
    .min(1, "Email is required")
    .email("Please enter a valid email"),

  password: z
    .string()
    .trim()
    .min(6, "Password must be at least 6 characters")
});

export type LoginFormData = z.infer<typeof loginSchema>;